# LevelUpDiag-Koali

LevelUpDiag-Koali est un appendice autonome de diagnostic et de validation utilisé à côté de kOA-Linux pendant le développement.

Son rôle est simple :

1. charger une configuration locale ;
2. lire un manifeste de niveaux ;
3. lancer une série de scripts `.py`, `.pyw` ou de commandes ;
4. respecter leur ordre et leurs dépendances simples ;
5. collecter les sorties et les logs ;
6. normaliser les verdicts ;
7. produire une vue cohérente de l'état de la cible.

LevelUpDiag-Koali n'est pas une partie de kOA-Linux. Il n'est pas requis au runtime et doit être retiré avant la préparation d'une livraison.

## Principes

- le manifeste décrit les niveaux ;
- chaque niveau reste exécutable indépendamment ;
- le runner orchestre sans réimplémenter la logique des checks ;
- les chemins et commandes locaux viennent de la configuration ;
- les résultats distinguent clairement un échec de la cible d'un problème d'environnement ;
- les logs sont regroupés par exécution ;
- la GUI est une façade pratique, pas une autorité ;
- kOA-Linux reste la cible observée et conserve ses propres règles.

## Structure documentaire

La documentation détaillée commence dans [`docs/README.md`](docs/README.md).

Les documents principaux sont :

- [`docs/01-overview.md`](docs/01-overview.md)
- [`docs/02-architecture.md`](docs/02-architecture.md)
- [`docs/03-levels-and-checks.md`](docs/03-levels-and-checks.md)
- [`docs/04-configuration.md`](docs/04-configuration.md)
- [`docs/05-execution-and-ordering.md`](docs/05-execution-and-ordering.md)
- [`docs/06-results-and-logs.md`](docs/06-results-and-logs.md)
- [`docs/07-koa-linux-integration.md`](docs/07-koa-linux-integration.md)
- [`docs/08-campaigns.md`](docs/08-campaigns.md)
- [`docs/09-failure-and-blocking-model.md`](docs/09-failure-and-blocking-model.md)
- [`docs/10-security.md`](docs/10-security.md)
- [`docs/11-cli-and-gui.md`](docs/11-cli-and-gui.md)
- [`docs/12-testing.md`](docs/12-testing.md)
- [`docs/13-removal-before-delivery.md`](docs/13-removal-before-delivery.md)
- [`docs/14-development.md`](docs/14-development.md)
- [`docs/15-reference.md`](docs/15-reference.md)

## Modèle mental

```text
config locale
     +
manifest
     ↓
runner
     ↓
N00 → N01 → N02 → ...
     ↓
résultats
     ↓
logs + rapport global
```

Un niveau peut lui-même appeler un script public de kOA-Linux, `pytest`, `cargo`, un outil système ou une autre commande autorisée.

## Répertoires runtime

Par défaut, les fichiers produits localement sont placés sous :

```text
.levelupdiag/
```

Ce répertoire contient l'état d'exécution, les logs et les rapports locaux. Il n'est pas destiné à être livré avec kOA-Linux.

## État du projet

LevelUpDiag-Koali est une adaptation spécialisée de LevelUpDiag pour accompagner le développement de kOA-Linux sans fusionner les deux dépôts.
